const validateUser = require('./validateuser');
const changePass = require('./changePass');
const usersByArea = require('./usersByArea');

module.exports={
    validateUser,
    changePass,
    usersByArea
};